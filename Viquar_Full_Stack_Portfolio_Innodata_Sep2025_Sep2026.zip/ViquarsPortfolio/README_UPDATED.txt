VIQUAR'S PORTFOLIO — UPDATED FULL STACK EDITION

HOW TO VIEW
1. Extract this ZIP file.
2. Open ViquarsPortfolio/Viquarsportfolio.html in a modern browser.
3. Keep Viquarsportfolio.css and sv.png in the same folder as the HTML file.

WHAT WAS UPDATED
- Modern responsive layout with mobile navigation.
- Full Stack Developer positioning and updated experience timeline.
- RITS Billing Suite highlighted as the featured full-stack project.
- Project descriptions, technology tags, skills, and contact section refreshed.
- Navigation, email, LinkedIn, and phone links made functional.
- Original supporting assets and other archive files retained.

PLEASE VERIFY BEFORE PUBLISHING
- Confirm the displayed profile photo is the one you want to use.
- Add your real GitHub profile and project repository/demo URLs when available.
- Confirm all project descriptions accurately reflect your individual contribution.
- The portfolio uses the contact details and experience timeline from your latest supplied CV.

ADDITIONAL UPDATE
- Added a Data Annotation Specialist / AI Trainer experience section.
- Included annotation, AI training, LLM response evaluation, content classification,
  guideline interpretation, data quality review, and Python coding-task experience.
- Added AI & Data Annotation to the technical skills section.
- No employer name or dates were assigned to this entry because those details were
  not confirmed for this portfolio version.

RESUME-DATE ALIGNMENT
- Innodata India Pvt. Ltd. — Data Annotator / AI Trainer: September 2025–September 2026.
- Handigital — Freelance Data Annotation Specialist: 3-month concurrent engagement.
  The resume does not specify exact calendar start/end months for Handigital, so none
  have been invented.
